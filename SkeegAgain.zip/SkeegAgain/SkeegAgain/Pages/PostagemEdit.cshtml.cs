using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MySql.Data.MySqlClient;

namespace SkeegAgain.Pages
{
    public class PostagemEditModel : PageModel
    {
        [BindProperty(SupportsGet = true)]

        public int Id { get; set; }

        [Required(ErrorMessage = "� obrigat�rio informar um T�tulo!")]
        [BindProperty(SupportsGet = true)]

        public string Titulo { get; set; }

        [Required(ErrorMessage = "� obrigat�rio informar um Conte�do!")]
        [BindProperty(SupportsGet = true)]

        public string Conteudo { get; set; }


        public async Task OnGet()
        {

            MySqlConnection mySqlConnection = new MySqlConnection("server=localhost;database=logindb;uid=root;password=Yashiro&yasuom7");

            await mySqlConnection.OpenAsync(); //abrindo a conex�o com o banco de dados

            MySqlCommand mySqlCommand = mySqlConnection.CreateCommand();

            mySqlCommand.CommandText = $"SELECT * FROM  postagem WHERE id = {Id}";

            MySqlDataReader reader = mySqlCommand.ExecuteReader();

            //7- se esse retorno pode ser lido no passo 6, ent�o da a mensagem "Usu�ro logado com suceso!" dentro do if
            if (await reader.ReadAsync())
            {
                Titulo = reader.GetString(1);
                Conteudo = reader.GetString(2);
            }

            await mySqlConnection.CloseAsync(); //fechando a conex�o com o banco de dados

        }

        public async Task<IActionResult> OnPost() //vai salvar os dados atualizado do usuario no banco
        {

            MySqlConnection mySqlConnection = new MySqlConnection("server=localhost;database=logindb;uid=root;password=Yashiro&yasuom7");

            await mySqlConnection.OpenAsync();

            MySqlCommand mySqlCommand = mySqlConnection.CreateCommand();

            mySqlCommand.CommandText = $"UPDATE postagem SET titulo = '{Titulo}', conteudo = '{Conteudo}' WHERE id = {Id} ";

            await mySqlCommand.ExecuteReaderAsync();

            await mySqlConnection.CloseAsync(); //fechando a conex�o com o banco de dados

            return RedirectToAction("HomeTime", "HomeTime");

        }

        public async Task<IActionResult> OnGetApagar()
        {

            MySqlConnection mySqlConnection = new MySqlConnection("server=localhost;database=logindb;uid=root;password=Yashiro&yasuom7");

            await mySqlConnection.OpenAsync();

            MySqlCommand mySqlCommand = mySqlConnection.CreateCommand();

            mySqlCommand.CommandText = $"DELETE FROM postagem WHERE id = {Id}";

            await mySqlCommand.ExecuteReaderAsync();

            await mySqlConnection.CloseAsync(); //fechando a conex�o com o banco de dados

            return RedirectToAction("HomeTime", "HomeTime");
        }

        }
    }

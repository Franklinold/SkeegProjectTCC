using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MySql.Data.MySqlClient;

namespace SkeegAgain.Pages
{
    public class PostagemCadastroModel : PageModel
    {

        [Required(ErrorMessage = "� obrigat�rio informar o Nome!")]
        [BindProperty(SupportsGet = true)]

        public string Titulo { get; set; }


        [Required(ErrorMessage = "� obrigat�rio informar o conte�do!")]
        [BindProperty(SupportsGet = true)]

        public string Conteudo { get; set; }

        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPostAsync()
        {
            MySqlConnection mySqlConnection = new MySqlConnection("server=localhost;database=logindb;uid=root;password=Yashiro&yasuom7");

            await mySqlConnection.OpenAsync();

            MySqlCommand mySqlCommand = mySqlConnection.CreateCommand();

            mySqlCommand.CommandText = $"INSERT INTO postagem (titulo, conteudo) VALUES ('{Titulo}', '{Conteudo}')";

            await mySqlCommand.ExecuteReaderAsync();

            await mySqlConnection.CloseAsync(); //fechando a conex�o com o banco de dados

            return RedirectToAction("HomeTime", "HomeTime");

        }
    }
}

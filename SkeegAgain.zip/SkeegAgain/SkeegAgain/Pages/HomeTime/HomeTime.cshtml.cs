using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MySql.Data.MySqlClient;

namespace SkeegAgain.Pages
{
    public class HomeTimeModel : PageModel
    {

        public List<HomeTimeModelViewModel> HomeTime { get; set; }

        public async Task OnGet()
        {
            MySqlConnection mySqlConnection = new MySqlConnection("server=localhost;database=logindb;uid=root;password=Yashiro&yasuom7");

            await mySqlConnection.OpenAsync(); //abrindo a conex�o com o banco de dados

            MySqlCommand mySqlCommand = mySqlConnection.CreateCommand();

            mySqlCommand.CommandText = $"SELECT * FROM  postagem";

            MySqlDataReader reader = mySqlCommand.ExecuteReader();

            HomeTime = new List<HomeTimeModelViewModel>(); //lista vazia

            while (await reader.ReadAsync())
            {
                HomeTime.Add(new HomeTimeModelViewModel
                {
                    Id = reader.GetInt32(0),
                    Titulo = reader.GetString(1),
                    Conteudo = reader.GetString(2),
                });


            }

            await mySqlConnection.CloseAsync(); //fechando a conex�o com o banco de dados

        }

        public class HomeTimeModelViewModel
        {

            public int Id { get; set; }

            public string Titulo { get; set; }

            public string Conteudo { get; set; }

        }

    }
}

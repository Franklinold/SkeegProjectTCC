using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MySql.Data.MySqlClient;

namespace SkeegAgain.Pages
{
    public class CadastrarModel : PageModel
    {
        
        [BindProperty(SupportsGet = true)]

        public string Email { get; set; }
           
      
        [BindProperty(SupportsGet = true)]

        public string Nome { get; set; }

        [BindProperty(SupportsGet = true)]

        public string Username { get; set; }

        [BindProperty(SupportsGet = true)]

        public string Senha { get; set; }

        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPostAsync()
        {               
            MySqlConnection mySqlConnection = new MySqlConnection("server=localhost;database=logindb;uid=root;password=Yashiro&yasuom7");
            
            await mySqlConnection.OpenAsync();

            MySqlCommand mySqlCommand = mySqlConnection.CreateCommand();

            mySqlCommand.CommandText = $"INSERT INTO login (nome, username, senha, email) VALUES ('{Nome}', '{Username}' , '{Senha}' , '{Email}')";

            await mySqlCommand.ExecuteReaderAsync();

            await mySqlConnection.CloseAsync(); //fechando a conex�o com o banco de dados

            return RedirectToAction("Index", "Login");

        }
    }
}

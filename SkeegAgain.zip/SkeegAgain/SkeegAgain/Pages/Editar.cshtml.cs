using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MySql.Data.MySqlClient;

namespace SkeegAgain.Pages
{
    public class EditarModel : PageModel
    {
        
        [BindProperty(SupportsGet = true)]

        public int Id { get; set; }

        [Required(ErrorMessage = "� obrigat�rio informar um Email!")]
        [BindProperty(SupportsGet = true)]

        public string Email { get; set; }

        [Required(ErrorMessage = "� obrigat�rio informar um Username!")]
        [BindProperty(SupportsGet = true)]

        public string Username { get; set; }

        [Required(ErrorMessage = "� obrigat�rio informar uma senha!")]
        [BindProperty(SupportsGet = true)]

        public string Senha { get; set; }

        public async Task OnGet()
        {
            if (User.Identity.IsAuthenticated)
            {

                MySqlConnection mySqlConnection = new MySqlConnection("server=localhost;database=logindb;uid=root;password=Yashiro&yasuom7");

                await mySqlConnection.OpenAsync(); //abrindo a conex�o com o banco de dados

                MySqlCommand mySqlCommand = mySqlConnection.CreateCommand();

                mySqlCommand.CommandText = $"SELECT * FROM  login WHERE id = {Id}";

                MySqlDataReader reader = mySqlCommand.ExecuteReader();

                //7- se esse retorno pode ser lido no passo 6, ent�o da a mensagem "Usu�ro logado com suceso!" dentro do if
                if (await reader.ReadAsync())
                {
                    Email = reader.GetString(1);
                    Username = reader.GetString(2);
                    Senha = reader.GetString(3);
                }

                await mySqlConnection.CloseAsync(); //fechando a conex�o com o banco de dados

            }

        }

        public async Task<IActionResult> OnPost() //vai salvar os dados atualizado do usuario no banco
        {
            

                MySqlConnection mySqlConnection = new MySqlConnection("server=localhost;database=logindb;uid=root;password=Yashiro&yasuom7");

                await mySqlConnection.OpenAsync();

                MySqlCommand mySqlCommand = mySqlConnection.CreateCommand();

                mySqlCommand.CommandText = $"UPDATE login SET nome = '{Email}', username = '{Username}', senha = '{Senha}' WHERE id = {Id} ";

                await mySqlCommand.ExecuteReaderAsync();

                await mySqlConnection.CloseAsync(); //fechando a conex�o com o banco de dados

                return new JsonResult(new { Msg = "Perfil editado com sucesso" });

            
        }

        public async Task<IActionResult> OnGetApagar()
        {

           

                MySqlConnection mySqlConnection = new MySqlConnection("server=localhost;database=logindb;uid=root;password=Yashiro&yasuom7");

                await mySqlConnection.OpenAsync();

                MySqlCommand mySqlCommand = mySqlConnection.CreateCommand();

                mySqlCommand.CommandText = $"DELETE FROM login WHERE id = {Id}";

                await mySqlCommand.ExecuteReaderAsync();

                await mySqlConnection.CloseAsync(); //fechando a conex�o com o banco de dados

                return new JsonResult(new { Msg = "Perfil deletado com sucesso!" });

            

        }
    }
}

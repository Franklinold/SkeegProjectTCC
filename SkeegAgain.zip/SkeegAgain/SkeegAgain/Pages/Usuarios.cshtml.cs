using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MySql.Data.MySqlClient;

namespace SkeegAgain.Pages
{
    public class UsuariosModel : PageModel
    {  
        public List<UsuarioViewModel> Usuarios { get; set; }

        public async Task OnGet()
        {      
            MySqlConnection mySqlConnection = new MySqlConnection("server=localhost;database=postagemdb;uid=root;password=Yashiro&yasuom7");
           
            await mySqlConnection.OpenAsync(); //abrindo a conex�o com o banco de dados

            MySqlCommand mySqlCommand = mySqlConnection.CreateCommand();

            mySqlCommand.CommandText = $"SELECT * FROM  postagem";
  
            MySqlDataReader reader = mySqlCommand.ExecuteReader();

            Usuarios = new List<UsuarioViewModel>(); //lista vazia

            while (await reader.ReadAsync())
            {
                Usuarios.Add(new UsuarioViewModel
                {
                    Id = reader.GetInt32(0),
                    Nome = reader.GetString(1),
                    Conteudo = reader.GetString(2),
                    Comentario = reader.GetString(3),
                });
                

            }

            await mySqlConnection.CloseAsync(); //fechando a conex�o com o banco de dados

        }

        public class UsuarioViewModel
        {

            public int Id { get; set; }

            public string Nome { get; set; }

            public string Conteudo { get; set; }

            public string Comentario { get; set; }
        }

    }
}

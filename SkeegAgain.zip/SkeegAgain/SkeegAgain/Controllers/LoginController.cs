﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Site_autenticacao.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            //confirmando que o usário esta logado
            if (User.Identity.IsAuthenticated) // verifica se o usuario estiver autenticado (logado)...
            {
                //...ele retorna essa mensagem informando que ele já esta logado
                return Json(new { Msg = "Usuário já logado!" });
            }
            return View(); //caso contrário retorna o usuário ao view index para fazer o login

        }

        //Definir que a action LOGAR é do tipo HttpPost, pois foi o que foi definido no formulario da pagina login
        [HttpPost]
        //criando a action LOGAR, que significa que assim que eu por usuario e senha a tela será trocada para essa action
                                  //definindo os campos que uso para fazer o login do usuário
        public async Task<IActionResult> Logar(string username, string senha, bool manterlogado)
        {
            //1- criando o objeto que vai fazer a conexão com o banco de dados
                  //2- esse objeto MySqlConnection pede uma string de conexão para parametro, então passamos os dados do banco:                 
            MySqlConnection mySqlConnection = new MySqlConnection("server=localhost;database=logindb;uid=root;password=Yashiro&yasuom7");
            //3- conexão feita, abrindo a conexão agora:
            await mySqlConnection.OpenAsync();

            //4- por esse objeto onde será consultado no banco as informações
            MySqlCommand mySqlCommand = mySqlConnection.CreateCommand();

            //5- definindo a query que será usando no banco (query é o meio de consulta)
            mySqlCommand.CommandText = $"SELECT * FROM  login WHERE username = '{username}' AND senha = '{senha}' ";

            //6- para retornar os dados do usuario que estão no banco (complemento do passo 6) precisa desse comando
            MySqlDataReader reader = mySqlCommand.ExecuteReader(); //manda ele executar a consulta 

            //7- se esse retorno pode ser lido no passo 6, então da a mensagem "Usuáro logado com suceso!" dentro do if
            if (await reader.ReadAsync())
            {
                //resgatando o id e o nome do usuario no banco de dados para efetuar o login
                                //resgatando do data reader um num int na posição 0 e 1 (essa posição é a ordem dos campos no banco de dados)
                int usuarioId = reader.GetInt32(0);
                string email = reader.GetString(1);

                //Para efetuar o login, é preciso definir os direitos de acesso do usário (nesse caso por meio de uma lista)
                List<Claim> direitosAcesso = new List<Claim> //direitos de acesso são baseados em claims
                {
                    //nessas claim pode-se definir o nome de usuario e qual o usuario que esta logado, pois caso seja preciso podemos resgatar depois pois ja temos
                    new Claim(ClaimTypes.NameIdentifier, usuarioId.ToString()),
                    new Claim(ClaimTypes.Email, email)
                };
                
                //essa variavel vai salvar os direitos de acesso numa especie de cookie (autenticação) chamado
                var identity = new ClaimsIdentity(direitosAcesso, "Identity.Login");
                //analisar
                var userPrincipal = new ClaimsPrincipal(new[] { identity });

                //Efetuando de fato o login, e definindo os parametros de login, que são as propriedades de autenticação
                await HttpContext.SignInAsync(userPrincipal, 
                    new AuthenticationProperties
                    {
                        
                       //esse basicamente é um botão de manter logado
                       IsPersistent = manterlogado, //esse é um botão que pode ser ativado pelo usuario, ele define se vai manter a conta logada ou não
                       ExpiresUtc = DateTime.Now.AddHours(12) //definindo a data de expiração para daqui a 1 hora, mas finalizar a config no startup
                    });

                //simulando um retorno se o usuario foi logado ou não (depois é só eu redirecionar para outra pagina no lugar)

                //sempre que o sistema identificar um usuario no banco de dados, exibiremos essa mensagem (ou redireciona para um site)

                //return Json(new { Msg = "Usuário logado com sucesso!" });
                return RedirectToAction("HomeTime", "HomeTime");
            }
            await mySqlConnection.CloseAsync(); //fechando a conexão com o banco de dados
            return RedirectToAction("Index", "Login");

        }

        //Criando outra action para deslogar o usuário
        public async Task<IActionResult> Logout()
        {
            //primeiro tem que verificar se o usuário esta logado, por motivos logicos
            if (User.Identity.IsAuthenticated)
            {
                //se o usuário estiver logado, ele desloga o usuário
                await HttpContext.SignOutAsync();

            }// e então retorna a view index para fazer o login novamente
            return RedirectToAction("Index", "Login");
        }
    }
}

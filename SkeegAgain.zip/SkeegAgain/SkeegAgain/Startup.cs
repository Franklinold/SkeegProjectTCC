using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SkeegAgain
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews();

            //Adicionando a autentica��o de login do usuario
            services.AddAuthentication("Identity.Login")
                //adicionado o cookie e as configura��es de acesso 
                .AddCookie("Identity.Login", config => {
                    config.Cookie.Name = "Identity.Login"; //nome do cookie (o cookie pode ter o mesmo nome que a autentica��o, n da problema)
                    config.LoginPath = "/Login"; //dando o endere�o da view de login
                    config.AccessDeniedPath = "/Home";//caso o usuario tome acesso negado ele ser� redirecionado para o endere�o colocado
                    config.ExpireTimeSpan = TimeSpan.FromHours(12); // o cookie ira expirar em 12 horas
                });

            services.AddRazorPages(); //adicionando o razor pages para fazer o crud
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }   
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthentication(); //S� definindo ao asp.net core que ele usar� a autentica��o 

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
                endpoints.MapRazorPages();
            });
        }
    }
}
